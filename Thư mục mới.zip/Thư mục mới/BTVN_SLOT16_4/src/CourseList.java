

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class CourseList {
    private final List<Course> courses;

    public CourseList() {
        this.courses = new ArrayList<>();
    }
    public void loadCoursesFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split("\\|");
                if (data.length == 5) {
                    Course course = new Course(data[0], data[1], data[2],data[3],Integer.parseInt(data[4]));
                    courses.add(course);
                }
            }
        } catch (IOException e) {
            System.out.println("Lỗi khi đọc tệp: " + e.getMessage());
        }
    }

    public void addCourse(Course course) { courses.add(course); }
    public List<Course> getCourses() { return courses; }

    public List<Course> getCoursesSortedByDuration() {
        return courses.stream().sorted(Comparator.comparingInt(Course::getDuration)).collect(Collectors.toList());
    }

    public Course searchCourseById(String courseId) {
        return courses.stream().filter(c -> c.getCourseId().equalsIgnoreCase(courseId)).findFirst().orElse(null);
    }

    public List<Course> searchCoursesByTitle(String title) {
        return courses.stream().filter(c -> c.getTitle().equalsIgnoreCase(title)).collect(Collectors.toList());
    }

    public List<Course> searchCoursesByDepartment(String department) {
        return courses.stream().filter(c -> c.getDepartment().equalsIgnoreCase(department)).collect(Collectors.toList());
    }

    public void removeOldCourses(int years) {
        LocalDate thresholdDate = LocalDate.now().minusYears(years);
        courses.removeIf(course -> course.getStartDate().isBefore(thresholdDate));
    }
}
