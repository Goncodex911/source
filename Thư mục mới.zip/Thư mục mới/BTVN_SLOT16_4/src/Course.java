


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

    public class Course {
        private final String courseId;
        private final String title;
        private final String department;
        private final LocalDate startDate;
        private final int duration;
        public Course(String courseId, String title, String department, String startDate, int duration) {
            this.courseId = courseId;
            this.title = title;
            this.department = department;
            this.startDate = LocalDate.parse(startDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            this.duration = duration;
        }

        public String getCourseId() { return courseId; }
        public String getTitle() { return title; }
        public String getDepartment() { return department; }
        public LocalDate getStartDate() { return startDate; }
        public int getDuration() { return duration; }
        @Override
        public String toString() {
            return courseId + " | " + title + " | " + department + " | " + startDate + " | " + duration;
        }
    }


