
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.List;

public class CourseManagement {
    private final CourseList courseList;

    public CourseManagement() {
        this.courseList = new CourseList();
    }

    public void loadCourses(String filename) throws FileNotFoundException { courseList.loadCoursesFromFile(filename); }

    public void addCourse(String courseId, String title, String department, String startDate, int duration) {
        addCourse(courseId, title, department, startDate, duration, LocalDate.MAX);
    }

    public void addCourse(String courseId, String title, String department, String startDate, int duration, LocalDate MAX) {
        Course newCourse = new Course(courseId, title, department, startDate, duration);
        courseList.addCourse(newCourse);
    }

    public List<Course> getAllCourses() { return courseList.getCourses(); }

    public List<Course> getCoursesSortedByDuration() { return courseList.getCoursesSortedByDuration(); }

    public Course searchCourseById(String courseId) { return courseList.searchCourseById(courseId); }

    public List<Course> searchCoursesByTitle(String title) { return courseList.searchCoursesByTitle(title); }

    public List<Course> searchCoursesByDepartment(String department) { return courseList.searchCoursesByDepartment(department); }

    public void removeOldCourses(int years) { courseList.removeOldCourses(years); }
}

