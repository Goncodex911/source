import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class File {
    public static void main(String[] args) {
        String content = """
                         1|Introduction to Java|100.000|15-09-2021
                         2|Data Structures|20000.000|01-02-2020
                         3|Database Systems|90.321|10-05-2022
                         4|Operating Systems|90123.1233|20-08-2019
                       
                         """;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("bill.txt"))) {
            writer.write(content);
            System.out.println("File created successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }
}
