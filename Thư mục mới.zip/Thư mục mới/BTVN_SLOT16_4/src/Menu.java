/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author THUAN
 */




import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Menu {
    private final CourseManagement courseManagement;
    private final Scanner scanner;

    public Menu() throws FileNotFoundException {
        this.courseManagement = new CourseManagement();
        this.scanner = new Scanner(System.in);
        courseManagement.loadCourses("courses.txt");
    }

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n--- Hệ thống quản lý khóa học ---");
            System.out.println("1. Thêm khóa học mới");
            System.out.println("2. Hiển thị tất cả khóa học");
            System.out.println("3. Hiển thị khóa học sắp xếp theo thời lượng");
            System.out.println("4. Tìm kiếm khóa học");
            System.out.println("5. Xóa khóa học cũ hơn 3 năm");
            System.out.println("6. Thoát");
            System.out.print("Nhập lựa chọn: ");
            choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1 -> addNewCourse();
                case 2 -> displayAllCourses();
                case 3 -> displaySortedCourses();
                case 4 -> searchForCourse();
                case 5 -> removeOldCourses();
                case 6 -> System.out.println("Đang thoát...");
                default -> System.out.println("Lựa chọn không hợp lệ. Thử lại.");
            }
        } while (choice != 6);
    }

    private void addNewCourse() {
        System.out.print("Nhập Mã Khóa Học: ");
        String courseId = scanner.nextLine();
        System.out.print("Nhập Tên Khóa Học: ");
        String title = scanner.nextLine();
        System.out.print("Nhập Khoa/Bộ Môn: ");
        String department = scanner.nextLine();
        System.out.print("Nhập Ngày Bắt Đầu (dd-MM-yyyy): ");
        String startDate = scanner.nextLine();
        System.out.print("Nhập Thời Lượng (số buổi): ");
        int duration = scanner.nextInt();
        scanner.nextLine();
        
        courseManagement.addCourse(courseId, title, department, startDate, duration, LocalDate.MAX);
        System.out.println(" Khoa hoc cap nhat thanh cong: ");

        
    }

    private void displayAllCourses() {
        List<Course> courses = courseManagement.getAllCourses();
        courses.forEach(System.out::println);
    }

    private void displaySortedCourses() {
        List<Course> sortedCourses = courseManagement.getCoursesSortedByDuration();
        sortedCourses.forEach(System.out::println);
    }

    private void searchForCourse() {
        System.out.println("Tìm kiếm theo: 1. Mã Khóa Học 2. Tên Khóa Học 3. Khoa/Bộ Môn");
        int searchChoice = scanner.nextInt();
        scanner.nextLine();

        switch (searchChoice) {
            case 1 -> {
                System.out.print("Nhập Mã Khóa Học: ");
                String courseId = scanner.nextLine();
                Course course = courseManagement.searchCourseById(courseId);
                System.out.println(course != null ? course : "Không tìm thấy khóa học.");
            }
            case 2 -> {
                System.out.print("Nhập Tên Khóa Học: ");
                String title = scanner.nextLine();
                List<Course> courses = courseManagement.searchCoursesByTitle(title);
                courses.forEach(System.out::println);
            }
            case 3 -> {
                System.out.print("Nhập Khoa/Bộ Môn: ");
                String department = scanner.nextLine();
                List<Course> courses = courseManagement.searchCoursesByDepartment(department);
                courses.forEach(System.out::println);
            }
            default -> System.out.println("Lựa chọn không hợp lệ.");
        }
    }

    private void removeOldCourses() {
        courseManagement.removeOldCourses(3);
        System.out.println("Các khóa học cũ hơn 3 năm đã được xóa.");
    }
}

    

