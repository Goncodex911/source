package com.jmc.librarymanagment.Controllers.Admin;

public class AdminMenuController {
}
