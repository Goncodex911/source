package com.jmc.librarymanagment.Controllers.Client;

import com.jmc.librarymanagment.Model.Model;
import com.jmc.librarymanagment.View.ClientMenuOption;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

public class ClientController implements Initializable {
   public BorderPane client_parent;
   public ClientController(){}
    @Override

    public void initialize(URL url, ResourceBundle resourceBundle) {
        Model.getInstance().getViewFactory().getClientMenuOption().addListener(this::change);
    }

    private void change(ObservableValue<? extends ClientMenuOption> observableValue, ClientMenuOption clientMenuOption, ClientMenuOption clientMenuOption1) {
        switch ((ClientMenuOption)clientMenuOption1)
        {
            case OPERATION -> {this.client_parent.setCenter(Model.getInstance().getViewFactory().getOperation());}
            case  TRANSACTIONS -> {this.client_parent.setCenter(Model.getInstance().getViewFactory().getTransactions());}
            default  ->{this.client_parent.setCenter(Model.getInstance().getViewFactory().getDashboard());}
        }

    }


}
