package com.jmc.librarymanagment.Model;

public class Admin {
}
