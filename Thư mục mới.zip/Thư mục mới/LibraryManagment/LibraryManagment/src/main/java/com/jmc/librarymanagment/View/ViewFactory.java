package com.jmc.librarymanagment.View;

import com.jmc.librarymanagment.Controllers.Client.ClientController;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ViewFactory {
    private AccountType acountType;
    private final ObjectProperty<ClientMenuOption>clientMenuOptionObjectProperty;
    private final ObjectProperty<AdminMenuOption>adminMenuOptionObjectProperty;
    private AnchorPane Dashboard;
    private  AnchorPane Transactions;
    private AnchorPane Operation;
    public ViewFactory()
    {     this.acountType= AccountType.CLIENT;
        this.clientMenuOptionObjectProperty=new SimpleObjectProperty<>();
        this.adminMenuOptionObjectProperty=new SimpleObjectProperty<>();
    }

    public AnchorPane getOperation() {
        if(this.Operation==null){
         try{   this.Operation= new FXMLLoader(this.getClass().getResource("/Fxml/Client/Operation.fxml")).load();
        }catch(Exception e){e.printStackTrace();}
        }
        return Operation;
    }

    public ObjectProperty<ClientMenuOption>getClientMenuOption(){return this.clientMenuOptionObjectProperty;}
    public ObjectProperty<AdminMenuOption>getAdminMenuOption(){return this.adminMenuOptionObjectProperty;}
    public AccountType getAccountType(){return this.acountType;}
    public void setAcountType(AccountType acountType){this.acountType=acountType;}
    public AnchorPane getTransactions(){
        if(this.Transactions==null){
            try{
            this.Transactions= new FXMLLoader(this.getClass().getResource("/Fxml/Client/Transactions.fxml")).load();}
            catch(Exception e){e.printStackTrace();}
        }
        return this.Transactions;
    }
    public AnchorPane getDashboard(){
        if(Dashboard==null){
            try{
                Dashboard= new FXMLLoader(this.getClass().getResource("/Fxml/Client/Dashboard.fxml")).load();
            }
            catch(Exception e){ e.printStackTrace();}
        }
        return this.Dashboard;
    }
    public void showLoginWindow(){
        FXMLLoader fxml=new FXMLLoader(this.getClass().getResource("/Fxml/LoginMenu.fxml"));
   createState(fxml);
    }
    public void showClientWindow(){
        FXMLLoader fxml=new FXMLLoader(this.getClass().getResource("/Fxml/Client/Client.fxml"));
        ClientController clientController=new ClientController();
        fxml.setController(clientController);
        this.createState(fxml);
    }
    private void createState(FXMLLoader fxml)
    {
        Scene scen= null;
        try{
            scen = new Scene((Parent)fxml.load());
        }catch(Exception e){e.printStackTrace();}
        Stage stage = new Stage();
        stage.setTitle("Library management ");
        stage.setScene(scen);
        stage.show();
    }
    public void closeState(Stage stage){
        stage.close();

    }

}
