package com.jmc.librarymanagment.Controllers.Client;

import javafx.scene.control.ListView;
import javafx.scene.text.Text;

public class DashboardController {
    public Text name_tf;
    public Text sl_bor_t;
    public ListView top_choice_lv;
    public Text sl_order_t;
    public Text income_t;
    public Text outcome_t;
    public Text date_tf;
    public ListView borr_lv;
    public ListView order_lv;
}
