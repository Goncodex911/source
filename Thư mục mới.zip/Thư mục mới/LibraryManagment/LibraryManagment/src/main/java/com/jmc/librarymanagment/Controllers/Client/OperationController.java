package com.jmc.librarymanagment.Controllers.Client;

import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class OperationController {
    public ListView list_lv;
    public TextField seatch_tf;
    public Text hello_btn;
    public Button search_btn;
    public ImageView image_img;
    public Button borrow_btn;
    public TextField book_name_tf;
    public TextField author_tf;
    public TextField price_tf;
    public TextField quantity_tf;
    public TextField status_tf;
    public TextField publis_tf;
    public TextField version_tf;
    public Button order_btn;
}
