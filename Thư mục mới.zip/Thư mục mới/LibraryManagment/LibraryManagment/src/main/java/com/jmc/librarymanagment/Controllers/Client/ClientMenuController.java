package com.jmc.librarymanagment.Controllers.Client;

import com.jmc.librarymanagment.Model.Model;
import com.jmc.librarymanagment.View.ClientMenuOption;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class ClientMenuController implements Initializable {




    public Button report_btn;
    public Button dashboard_btn;
    public Button transaction_btn;
    public Button operation_btn;
    public Button logout_btn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
      this.addListener();
    }
    private void  addListener(){
    logout_btn.setOnAction(e->{onLogout();});
    dashboard_btn.setOnAction(e->onDashboard());
    operation_btn.setOnAction(e->onOperation());
    transaction_btn.setOnAction(e->onTransactions());
    }
    private void onDashboard(){
        Model.getInstance().getViewFactory().getClientMenuOption().set(ClientMenuOption.DASHBOARD);
    }
    private  void  onOperation(){
        Model.getInstance().getViewFactory().getClientMenuOption().set(ClientMenuOption.OPERATION);

    }
    private void onTransactions(){Model.getInstance().getViewFactory().getClientMenuOption().set(ClientMenuOption.TRANSACTIONS);}

    private  void onLogout(){
        Stage temp= (Stage)logout_btn.getScene().getWindow();
        Model.getInstance().getViewFactory().closeState(temp);
        Model.getInstance().getViewFactory().showLoginWindow();
    }
}
