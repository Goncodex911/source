package com.jmc.librarymanagment.View;

public enum AdminMenuOption {
    STATISTIC,
    MANAGEBOOK,
    MANAGEUSER,
    LOGOUT;
    private  AdminMenuOption(){}

}
