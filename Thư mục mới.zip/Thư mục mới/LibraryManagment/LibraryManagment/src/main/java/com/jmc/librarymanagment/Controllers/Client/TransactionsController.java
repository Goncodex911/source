package com.jmc.librarymanagment.Controllers.Client;

import javafx.scene.control.ListView;

public class TransactionsController {
    public ListView Transactions_lv;
}
