package com.jmc.librarymanagment.View;

public enum AccountType {
    ADMIN,
    CLIENT;
    private AccountType(){}
}
