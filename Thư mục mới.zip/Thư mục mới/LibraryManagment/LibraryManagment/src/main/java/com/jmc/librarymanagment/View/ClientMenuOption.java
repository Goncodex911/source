package com.jmc.librarymanagment.View;

public enum ClientMenuOption {
    DASHBOARD,
    OPERATION,
    TRANSACTIONS,
    LOGOUT;
    private ClientMenuOption(){}
}
