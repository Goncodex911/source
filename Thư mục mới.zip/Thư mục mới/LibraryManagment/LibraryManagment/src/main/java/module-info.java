module com.jmc.librarymanagment {
    requires de.jensd.fx.glyphs.fontawesome;
    requires java.sql;
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires jdk.jshell;
    requires kotlin.stdlib;
    opens com.jmc.librarymanagment to javafx.fxml;
    exports com.jmc.librarymanagment;
    exports com.jmc.librarymanagment.Controllers;
    exports com.jmc.librarymanagment.Controllers.Admin;
    exports com.jmc.librarymanagment.Controllers.Client;
    exports com.jmc.librarymanagment.Model;
    exports com.jmc.librarymanagment.View;
}