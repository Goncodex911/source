package controller;

import model.RiceVarietyList;
import view.Menu;

public class RiceVarietyManagement {

    public static void main(String[] args) {
        RiceVarietyList ricelist = new RiceVarietyList();
        ricelist.readfile(ricelist.filename);
        Menu menu = new Menu(ricelist);
        menu.run();
    }

}
