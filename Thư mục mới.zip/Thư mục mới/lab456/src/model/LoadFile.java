/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author THUAN
 */

    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author THUAN
 */   import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public class LoadFile {
    public static void main(String[] args) {
        String content = """
                         Jasmine,Thailand,01/01/2010,5.6,High
                         Basmati,India,15//2015,4.8,Moderate
                         Japonica,Japan,10/10/2018,5.0,Low
                         Arborio,Italy,05/05/2020,3.2,Moderate
                         Calrose,USA,22/11/2008,4.5,High
                       
                         """;

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("rice_varieties.csv"))) {
            writer.write(content);
            System.out.println("File created successfully!");
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }
}

    


    

