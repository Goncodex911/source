package model;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class RiceVariety {

    private String name;
    private String origin;
    private LocalDate harvestDate;
    private double yield;
    private String diseaseResistance;

    public RiceVariety() {
    }

    public RiceVariety(String name, String origin, String harvestDate, double yield, String diseaseResistance) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        this.name = name;
        this.origin = origin;
        try {
            this.harvestDate = LocalDate.parse(harvestDate, formatter);
        } catch (DateTimeParseException e) {
            System.out.println("invalid date format");
        }
        this.yield = yield;
        this.diseaseResistance = diseaseResistance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public LocalDate getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(LocalDate harvestDate) {
        this.harvestDate = harvestDate;
    }

    public double getYield() {
        return yield;
    }

    public void setYield(double yield) {
        this.yield = yield;
    }

    public String getDiseaseResistance() {
        return diseaseResistance;
    }

    public void setDiseaseResistance(String diseaseResistance) {
        this.diseaseResistance = diseaseResistance;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return "RiceVariety{"
                + "name='" + name + '\''
                + ", origin='" + origin + '\''
                + ", harvestDate=" + harvestDate.format(formatter)
                + ", yield=" + yield
                + ", diseaseResistance='" + diseaseResistance + '\''
                + '}';
    }

    public int getAge(int years) {
        LocalDate currentdate = LocalDate.now();
        years = Period.between(harvestDate, currentdate).getYears();
        return years;
    }
}
