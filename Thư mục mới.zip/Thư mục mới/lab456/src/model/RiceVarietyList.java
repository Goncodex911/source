package model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RiceVarietyList {

    private List<RiceVariety> ricelist = new ArrayList<>();
    public String filename = "D:\\PRO192\\lab456\\src\\model\\rice_varieties.csv";
    Scanner sc = new Scanner(System.in);
    RiceVariety ricevariety = new RiceVariety();

    public void readfile(String filename) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    try {
                        String name = parts[0].trim();
                        String origin = parts[1].trim();
                        String harvestDate = parts[2].trim();
                        double yield = Double.parseDouble(parts[3].trim());
                        String diseaseResistance = parts[4].trim();

                        try {
                            LocalDate date = LocalDate.parse(harvestDate, formatter);
                            ricelist.add(new RiceVariety(name, origin, harvestDate, yield, diseaseResistance));
                        } catch (DateTimeParseException e) {
                            System.out.println("invalid date format");
                        }
                    } catch (Exception e) {
                        System.out.println("invalid format, try again");
                    }
                }
            }
        } catch (IOException ioe) {
            System.out.println(ioe.getMessage());
        }
    }

    public void addrice(String name, String origin, String harvestDate, double yield, String diseaseresistance) {
        RiceVariety ricevariety = new RiceVariety(name, origin, harvestDate, yield, diseaseresistance);
        ricelist.add(ricevariety);
    }

    public void searchrice(String search) {
        for (RiceVariety ricevariety : ricelist) {
            if (ricevariety.getName().equalsIgnoreCase(search) || ricevariety.getOrigin().equalsIgnoreCase(search) || ricevariety.getDiseaseResistance().equalsIgnoreCase(search)) {
                System.out.println(ricevariety);
            }
        }
    }

    public void deleterice() {
        List<RiceVariety> ricelist1 = new ArrayList<>();
        LocalDate currentdate = LocalDate.now();
        for (RiceVariety ricevariety : ricelist) {
            if (ricevariety.getHarvestDate().isBefore(currentdate.minusYears(10))) {
                ricelist1.add(ricevariety);
            }
        }
        ricelist.removeAll(ricelist1);
    }

    public void displayrice() {
        for (RiceVariety ricevariety : ricelist) {
            if (ricevariety != null) {
                System.out.println(ricevariety);
            } else {
                System.out.println("Rice variety information is missing.");
            }
        }
    }

    public boolean updaterice(String name, double newyield, String newdiseaseresistance) {
        for (RiceVariety ricevariety : ricelist) {
            if (ricevariety.getName().equalsIgnoreCase(name)) {
                ricevariety.setYield(newyield);
                ricevariety.setDiseaseResistance(newdiseaseresistance);
                return true;
            }
        }
        return false;
    }
}
