package view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import model.RiceVariety;
import model.RiceVarietyList;

public class Menu extends RiceVarietyListView {

    Scanner sc = new Scanner(System.in);
    private RiceVarietyList ricelist;

    public Menu(RiceVarietyList ricelist) {
        super("Rice Variety Management", new String[]{
            "1. Add a new rice variety",
            "2. Display all rice varieties",
            "3. Update information of a rice variety",
            "4. Search rice varieties",
            "5. Delete old rice varieties",});
        this.ricelist = ricelist;
    }

    @Override
    public void execute(int n) {
        switch (n) {
            case 1 -> addrice();
            case 2 -> ricelist.displayrice();
            case 3 -> updaterice();
            case 4 -> searchrice();
            case 5 -> ricelist.deleterice();
            default -> System.out.println("Invalid selection, please try again.");
        }

    }

    public void addrice() {
        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter origin: ");
        String origin = sc.nextLine();
        double yield = 0.0;
        while (true) {

            try {
                System.out.print("Enter yield: ");
                yield = Double.parseDouble(sc.nextLine());
                break;
            } catch (NumberFormatException e) {
                System.out.println("invalid number");
            }

        }

        System.out.print("Enter diseaseResistance: ");
        String diseaseResistance = sc.nextLine();

        String harvestDate = null;
        while (true) {
            try {
                System.out.print("Enter harvest date (dd/MM/yyyy): ");
                harvestDate = sc.nextLine();
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                LocalDate date = LocalDate.parse(harvestDate, formatter);
                RiceVariety ricevariety = new RiceVariety(name, origin, date.format(formatter), yield, diseaseResistance);
                ricelist.addrice(name, origin, date.format(formatter), yield, diseaseResistance);
                break;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format");
            }
        }

        System.out.println("rice added ");
    }

    public void searchrice() {
        System.out.print("Enter name or origin or disease resistance level to search: ");
        String search = sc.nextLine();
        ricelist.searchrice(search);
    }

    public void updaterice() {
        System.out.println("enter name to update:");
        String name = sc.nextLine();
        double newyield = 0.0;
        while (true) {
            try {
                System.out.println("enter new yield:");
                newyield = Double.parseDouble(sc.nextLine());
                break;
            } catch (NumberFormatException e) {
                System.out.println("invalid number");
            }
        }
        System.out.println("enter new disease resistance:");
        String newdiseaseresistance = sc.nextLine();

        if (ricelist.updaterice(name, newyield, newdiseaseresistance)) {
            System.out.println("updated");
        } else {
            System.out.println("not found");
        }
    }
}
