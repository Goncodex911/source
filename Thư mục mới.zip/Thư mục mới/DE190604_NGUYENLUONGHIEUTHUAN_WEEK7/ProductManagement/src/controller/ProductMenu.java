package controller;

import model.Product;
import model.ProductList;
import view.Menu;
import view.ProductManagement;

import java.util.Arrays;
import java.util.List;

public class ProductMenu extends Menu<String> {
    ProductManagement productManagement = new ProductManagement();
    ProductList productList = new ProductList();
    public ProductMenu() {
        super("Product Management", Arrays.asList(
                "1.Add New Product",
                "2.Display Last Added Product",
                "3.Search Product by Name",
                "4.Update Product by ID",
                "5.Delete Product by ID"
        ));
    }

    @Override
    protected void execute(int choice) {
        switch (choice) {
            case 1:
                System.out.println("Adding new product...");
                productManagement.addProduct();

                break;
            case 2:
                System.out.println("Displaying last added product...");
                productList.displayProduct(productList.getLastProduct().orElse(null));
                break;
            case 3:
                System.out.println("Searching product by name...");
                productManagement.searchProduct();
                break;
            case 4:
                System.out.println("Updating product by ID...");
                productManagement.updateProductById();
                break;
            case 5:
                System.out.println("Deleting product by ID...");
                productManagement.deleteProduct();
                break;
            default:
                System.out.println("Invalid choice!");
        }
    }
}
