package controller;

import model.Product;
import model.ProductList;
import view.Menu;

import  view.ProductManagement;
import view.Menu;

import java.util.List;


public class Main {
    public static void main(String[] args) {
        ProductMenu productMenu = new ProductMenu();
        productMenu.run();

    }
}

