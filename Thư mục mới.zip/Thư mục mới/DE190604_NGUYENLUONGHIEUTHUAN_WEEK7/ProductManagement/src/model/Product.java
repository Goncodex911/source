package model;

public class Product {
   protected String productId;
   protected   String productName;
   protected   float price;
   protected  String manufacturer;
   public Product(){}
     public Product(String productId,String productName,float price,String manufacturer){
         if (price <= 0) throw new IllegalArgumentException("Price must be greater than 0.");
       this.productId = productId;
       this.productName = productName;
       this.price = price;
       this.manufacturer = manufacturer;
     }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        if (price <= 0) throw new IllegalArgumentException("Price must be greater than 0.");
        this.price = price;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public String toString() {
        return "Product{" +
                "manufacturer='" + manufacturer + '\'' +
                ", productId='" + productId + '\'' +
                ", productName='" + productName + '\'' +
                ", price=" + price +
                '}';
    }
}
