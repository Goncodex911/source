package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Food extends Product {
    private Date expirationDate;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");

    public Food(String productId, String productName, float price, String manufacturer, String expirationDate) throws ParseException {
        super(productId, productName, price, manufacturer);
        this.expirationDate = DATE_FORMAT.parse(expirationDate);
    }

    public String getExpirationDate() { return DATE_FORMAT.format(expirationDate); }

    public void setExpirationDate(String expirationDate) throws ParseException {
        this.expirationDate = DATE_FORMAT.parse(expirationDate);
    }

    @Override
    public String toString() {
        return "Food{" +
                "expirationDate=" + expirationDate +
                "} " + super.toString();
    }
}

