package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProductList {
    private List<Product> productList;
    public  ProductList(){
        this.productList = new ArrayList<>();
    }
    public void addProduct(Product product){
        productList.add(product);

    }
    public List<Product> getProductList(){
        return  new ArrayList<>(productList);
    }
    public Product searchProductByName(String productName){
        List<Product> find = new ArrayList<>();
        for(Product product : productList){
            if(product.getProductName().toLowerCase().contains(productName.toLowerCase())){
                find.add(product);
            }
        }
        return (Product) find;
    }
    public boolean updateById(String productId, Product update){
        for(int i = 0 ; i < productList.size(); i++){
            if(productList.get(i).getProductId().equalsIgnoreCase(productId)){
                productList.set(i,update);
                return  true;
            }
        }
        return  false;

    }
    public Product findProductById(String productId) {
        for (Product product : productList) {
            if (product.getProductId().equalsIgnoreCase(productId)) {
                return product;
            }
        }
        return null;
    }
    public  boolean deleteProduct(String productId){
        return  productList.removeIf(product -> product.getProductId().equalsIgnoreCase(productId));
    }
    public Optional<Product> getLastProduct(){
        if(productList.isEmpty()){
            return  Optional.empty();
        }else {
            return  Optional.of(productList.get(productList.size()-1));
        }

    }
    public  void clearProduct(){
        productList.clear();
    }
    public void displayMessage(String message) {
        System.out.println(message);
    }

    public void displayProduct(Product product) {
        if (product != null) {
            System.out.println(product);
        } else {
            System.out.println("Product not found.");
        }
    }

    public void displayProductList(List<Product> products) {
        if (products.isEmpty()) {
            System.out.println("No products available.");
        } else {
            products.forEach(System.out::println);
        }
    }
}

