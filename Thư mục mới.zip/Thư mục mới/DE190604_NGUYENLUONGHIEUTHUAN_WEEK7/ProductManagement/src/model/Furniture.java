package model;

public class Furniture extends  Product{
    private  String material;

    public Furniture(String productId, String productName, float price, String manufacturer, String material) {
        super(productId, productName, price, manufacturer);
        this.material = material;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return "Furniture{" +
                "material='" + material + '\'' +
                "} " + super.toString();
    }
}
