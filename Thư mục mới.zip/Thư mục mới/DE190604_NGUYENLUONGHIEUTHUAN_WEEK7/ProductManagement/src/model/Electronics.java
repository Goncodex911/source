package model;

public class Electronics extends  Product{
    private  int warrantyYears;
    public Electronics(String productId, String productName, float price, String manufacturer, int warrantyYears) {
        super(productId, productName, price, manufacturer);
        if (warrantyYears < 0) throw new IllegalArgumentException("Warranty years must be non-negative.");
        this.warrantyYears = warrantyYears;
    }

    public int getWarrantyYears() {
        return warrantyYears;
    }

    public void setWarrantyYears(int warrantyYears) {
        if(warrantyYears < 0 ) throw new IllegalArgumentException("nam phai lon hon 0.");
        this.warrantyYears = warrantyYears;
    }

    @Override
    public String toString() {
        return "Electronics{" +
                "warrantyYears=" + warrantyYears +
                "} " + super.toString();
    }
}
