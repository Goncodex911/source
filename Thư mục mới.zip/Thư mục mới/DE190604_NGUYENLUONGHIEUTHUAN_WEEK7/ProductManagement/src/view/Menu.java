package view;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.Scanner;

public abstract class Menu<T> {
    protected String title;
    protected List<T> options;
    protected Scanner scanner = new Scanner(System.in);

    public Menu(String title, List<T> options) {
        this.title = title;
        this.options = options;
    }

    public void display() {
        System.out.println("\n=== " + title + " ===");
        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ". " + options.get(i));
        }
        System.out.println("0. Exit");
    }

    public int getUserChoice() {
        int choice;
        while (true) {
            try {
                System.out.print("Enter your choice: ");
                choice = Integer.parseInt(scanner.nextLine());
                if (choice >= 0 && choice <= options.size()) {
                    return choice;
                }
                System.out.println("Invalid choice! Please enter a number between 0 and " + options.size());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        }
    }

    public void run() {
        while (true) {
            display();
            int choice = getUserChoice();
            if (choice == 0) {
                System.out.println("Exiting menu...");
                break;
            }
            execute(choice);
        }
    }
    protected abstract void execute(int choice);
}




