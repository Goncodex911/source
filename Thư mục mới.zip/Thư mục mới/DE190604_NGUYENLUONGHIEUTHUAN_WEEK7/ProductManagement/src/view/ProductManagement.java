package view;

import model.*;

import java.util.List;
import java.util.Scanner;

public class ProductManagement {
    private final ProductList productLists = new ProductList();
    private final Scanner scanner = new Scanner(System.in);

    public void addProduct() {
        System.out.println(" Nhap vao lua chon ( 1.Electrics , 2.Furniture , 3.Food).");
        int type = Validation.inputLimitedPositiveInt(1, 3);
        scanner.nextLine();
        System.out.println("nhap vao Id cua san pham: ");
        String productID = Validation.inputString();
        System.out.println(" nhap vao ten san pham: ");
        String productName = Validation.inputName();
        System.out.println("nhap vao gia san pham");
        float price = Validation.getValidAmount(" gia san pham la :");
        System.out.println("nhap vao nha san xuat:");
        String manufacturer = Validation.inputString();
        try {
            Product products = switch (type) {
                case 1 -> {
                    System.out.println(" mhap vao nam san xuat: ");

                    int warrantyYears = Validation.inputPositiveInt();
                    yield new Electronics(productID, productName, price, manufacturer, warrantyYears);
                }

                case 2 -> {
                    System.out.println(" nhap material: ");

                    String material = Validation.inputString();
                    yield new Furniture(productID, productName, price, manufacturer, material);
                }

                case 3 -> {
                    System.out.println(" nhap expiration date ( dd -mm -yyyy ");

                    String expirationDate = Validation.inputString();
                    yield new Food(productID, productName, price, manufacturer, expirationDate);
                }
                default -> throw new IllegalStateException("ko co loai phu hop " + type);


            };
            productLists.addProduct(products);
            System.out.println(" da them thanh cong");
        } catch (Exception e) {
            System.out.println(" chua thanh cong");
        }
    }
    public void searchProduct(){
        System.out.println(" nhap vao cai ten ma ban muon tim no: ");
        String name = Validation.inputName();
        productLists.searchProductByName(name);


    }
    public void updateProductById(){
        System.out.println(" nhap vao product id can update: ");
        String id = Validation.inputString();
        Product extProduct = productLists.findProductById(id);
        if(extProduct == null){
            System.out.println(" ko tom thay sp");
            return;
        }
        System.out.println(" nhap gia moi: ");
        float newPrice = Validation.getValidAmount(" nhap gia moi : ");
        System.out.println(" nhap nha sx moi :");
        String newManufacturer = Validation.inputString();
        extProduct.setPrice(newPrice);
        extProduct.setManufacturer(newManufacturer);
        System.out.println(" da update thanh cong.");
    }
    public  void deleteProduct(){
        System.out.println(" nhap vao id can xoa ");
        String id = Validation.inputString();
        if(productLists.deleteProduct(id)){
            System.out.println("xoa thanh cong ");
        }else{
            System.out.println("xoa that bai");
        }
    }


}