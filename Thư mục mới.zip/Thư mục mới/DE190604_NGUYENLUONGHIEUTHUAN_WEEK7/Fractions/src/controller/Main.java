package controller;

import model.FractionsList;
import view.FractionManagement;

public class Main {
    public static void main(String[] args) {
        FractionsList fractionList= new FractionsList();
        FractionManagement fractionManagement= new FractionManagement();
        fractionManagement.generate(fractionList);
        fractionManagement.display(fractionList);

    }
}
