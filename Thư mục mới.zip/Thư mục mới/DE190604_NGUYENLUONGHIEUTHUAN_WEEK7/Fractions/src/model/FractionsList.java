
package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FractionsList {
    private List<Fractions> fractions;

    public FractionsList() {
        this.fractions = new ArrayList<>();
    }

    public void generateList(int size){
        for(int i=0; i<size;i++){
            fractions.add(Fractions.generateFraction());
        }
        Collections.sort(fractions);
    }



    public Fractions getSum(){
        if(fractions.isEmpty()){
            return null;
        }

        Fractions fractionResult= fractions.get(0);
        for(int i=1; i<fractions.size();i++){
            fractionResult=Fractions.addFraction(fractionResult, fractions.get(i));
        }
        return fractionResult;
    }

    public List<Fractions> getFractions() {
        return fractions;
    }




}
