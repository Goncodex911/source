
package model;

import java.util.Random;

public class Fractions implements Comparable<Fractions> {

    private int numerator;
    private int denominator;

    public Fractions() {
    }

    public Fractions(int numerator, int denominator) {
        this.numerator = numerator;
        if (denominator == 0) {
            throw new NumberFormatException("denomiator must not be 0");
        }

        this.denominator = denominator;
    }

    public static Fractions getMinimalistFraction(Fractions fraction) {
        int gcd = gcd(fraction.getNumerator(), fraction.getDenominator());
        return new Fractions(fraction.getNumerator() / gcd, fraction.getDenominator() / gcd);
    }

    public static Fractions addFraction(Fractions fraction1, Fractions fraction2) {
        return new Fractions(
                fraction1.getNumerator() * fraction2.getDenominator() + fraction2.getNumerator() * fraction1.getDenominator(),
                fraction1.getDenominator() * fraction2.getDenominator());
    }

    public static Fractions generateFraction(){
        Random random = new Random();
        return new Fractions(random.nextInt(10), random.nextInt(10)+1);
    }

    public Fractions mapToFraction(String fraction) {
        Fractions fraction1 = new Fractions();

        String[] f = fraction.split("/");
        try {
            fraction1.setNumerator(Integer.parseInt(f[0]));
            fraction1.setDenominator(Integer.parseInt(f[1]));
        } catch (Exception e) {
            System.out.println("Wrong number format");
        }

        return fraction1;
    }

    public int getNumerator() {
        return numerator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    public void setDenominator(int denominator) {
        this.denominator = denominator;
    }

    static int gcd(int a, int b) {
        int i;
        if (a < b) {
            i = a;
        } else {
            i = b;
        }

        for (i = i; i > 1; i--) {
            if (a % i == 0 && b % i == 0) {
                return i;
            }
        }

        return 1;
    }

    @Override
    public int compareTo(Fractions o) {
        return Double.compare((this.numerator / this.denominator), (o.getNumerator() / o.getDenominator()));
    }

    @Override
    public String toString() {
        return numerator + "/" + denominator;
    }

}
