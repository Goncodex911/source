package view;

import model.Fractions;
import model.FractionsList;

import java.util.Scanner;

public class FractionManagement {
    public void display(FractionsList fractionsList) {
        for (Fractions fraction : fractionsList.getFractions()) {
            System.out.print(fraction + " ");
        }
        System.out.println();
        System.out.println("Sum of the fraction list:"+Fractions.getMinimalistFraction(fractionsList.getSum()));
    }

    public void generate(FractionsList fractionList) {
        int size = inputPositiveInt();
        fractionList.generateList(size);
    }

    public static int inputPositiveInt() {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        int inputInt = -1;
        do {
            try {
                System.out.println("(Input a positive integer)");
                inputInt = Integer.parseInt(scanner.nextLine());
                cont = false;
                if (inputInt <= 0) {
                    System.out.println("(Input a positive integer!)");
                    System.out.println("-----------------------");
                    cont = true;
                }
            } catch (Exception e) {
                System.out.println("(Input a positive integer!)");
                System.out.println("-----------------------");
            }

        } while (cont);
        return inputInt;
    }
}
