import java.io.*;
import java.util.regex.*;
public class Normalize {


        public static void main(String[] args) {
            String inputFile = "input.txt";
            String outputFile = "output.txt";

            try {
                String content = readFile(inputFile);
                String normalizedContent = normalizeText(content);
                writeFile(outputFile, normalizedContent);
                System.out.println("Text normalization completed. Check output.txt");
            } catch (IOException e) {
                System.out.println("Error processing file: " + e.getMessage());
            }
        }
        private static String readFile(String filePath) throws IOException {
            StringBuilder content = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    content.append(line.trim()).append(" ");
                }
            }
            return content.toString();
        }
        private static String normalizeText(String text) {
            text = text.replaceAll("\\s+", " ");
            text = text.replaceAll("\\s*([,.])\\s*", "$1 ");
            text = text.replaceAll("\\s*:\\s*", ": ");
            text = text.replaceAll("\\s*\"\\s*(.*?)\\s*\"\\s*", " \"$1\" ");
            if (!text.isEmpty()) {
                text = Character.toUpperCase(text.charAt(0)) + text.substring(1);
            }
            Pattern pattern = Pattern.compile("(\\.\\s+)([a-z])");
            Matcher matcher = pattern.matcher(text);
            StringBuffer result = new StringBuffer();
            while (matcher.find()) {
                matcher.appendReplacement(result, matcher.group(1) + matcher.group(2).toUpperCase());
            }
            matcher.appendTail(result);
            text = result.toString();
            if (!text.endsWith(".")) {
                text += ".";
            }
            return text.trim();
        }
        private static void writeFile(String filePath, String content) throws IOException {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                writer.write(content);
            }
        }
    }


