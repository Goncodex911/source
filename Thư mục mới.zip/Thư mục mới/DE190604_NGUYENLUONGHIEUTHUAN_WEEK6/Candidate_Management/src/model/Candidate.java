package model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Candidate {
    protected  String Candidate_Id;
    protected  String FirstName;
    protected   String LastName;
    protected Date BirthDate;
    protected  String Address;
    protected  String Phone;
    protected  String Email;
    protected  int Candidate_Type;
    public  Candidate(String Candidate_Id, String FirstName, String LastName, Date  BirthDate, String Address, String Phone, String Email, int Candidate_Type){
        this.Candidate_Id = Candidate_Id;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.BirthDate = BirthDate;
        this.Address = Address;
        this.Phone = Phone;
        this.Email = Email;
        this.Candidate_Type = Candidate_Type;

    }

    public String getCandidate_Id() {
        return Candidate_Id;
    }

    public String getName() {
        return FirstName+" \t "+LastName;
    }

    public String getBirthDate() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-mm-yyyy");
        return simpleDateFormat.format(BirthDate);
    }

    public String getPhone() {
        return Phone;
    }

    public String getAddress() {
        return Address;
    }

    public String getEmail() {
        return Email;
    }

    public int getCandidate_Type() {
        return Candidate_Type;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public void setBirthDate(Date birthDate) {
        BirthDate = birthDate;

    }

    public void setCandidate_Id(String candidate_Id) {
        Candidate_Id = candidate_Id;
    }

    public void setCandidate_Type(int candidate_Type) {
        Candidate_Type = candidate_Type;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    @Override
    public String toString() {
        return "Candidate{" +
                "Candidate_Id='" + Candidate_Id + '\'' +
                ", FirstName='" + FirstName + '\'' +
                ", LastName='" + LastName + '\'' +
                ", BirthDate=" + getBirthDate() +
                ", Address='" + Address + '\'' +
                ", Phone='" + Phone + '\'' +
                ", Email='" + Email + '\'' +
                ", Candidate_Type=" + Candidate_Type +
                '}';
    }
}
