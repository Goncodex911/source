package model;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CandidateList {
    private List<Candidate> candidateList = new ArrayList<>();
    public void addCandidate(Candidate candidate){
        candidateList.add(candidate);
    }
    public List<Candidate> searchCandidate(String name, int type){
        if (candidateList.isEmpty()){
            System.out.println(" Danh sach bi rong.");
        }else{
            return candidateList.stream().filter(candidate -> (candidate.getName().toLowerCase().contains(name.toLowerCase())) && candidate.getCandidate_Type() == type).collect(Collectors.toList());
        }


        return null;
    }
    public  List<Candidate> getCandidateList(){
        return  candidateList;
    }

}
