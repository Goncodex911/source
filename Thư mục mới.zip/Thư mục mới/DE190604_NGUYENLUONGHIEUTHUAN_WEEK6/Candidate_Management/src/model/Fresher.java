package model;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

public class Fresher extends  Candidate{
    private LocalDate Graduation_Date;
    private  String Graduation_Rank;
    private  String Education;


    public Fresher(String Candidate_Id, String FirstName, String LastName, Date BirthDate, String Address, String Phone, String Email, int Candidate_Type,LocalDate Graduation_Date,String Graduation_Rank,String Education) {

        super(Candidate_Id, FirstName, LastName, BirthDate, Address, Phone, Email, Candidate_Type);
        this.Graduation_Date = Graduation_Date;
        this.Graduation_Rank = Graduation_Rank;
        this.Education = Education;
    }


    public String getGraduation_Date() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-mm-yyyy");
        return  simpleDateFormat.format(Graduation_Date);
    }

    public void setGraduation_Date(LocalDate graduation_Date) {
        Graduation_Date = graduation_Date;
    }

    public String getGraduation_Rank() {
        return Graduation_Rank;
    }

    public void setGraduation_Rank(String graduation_Rank) {
        Graduation_Rank = graduation_Rank;
    }

    public String getEducation() {
        return Education;
    }

    public void setEducation(String education) {
        Education = education;
    }

    @Override
    public String toString() {
        return "Fresher{" +
                "Education='" + Education + '\'' +
                ", Graduation_Date=" + getGraduation_Date() +
                ", Graduation_Rank='" + Graduation_Rank + '\'' +
                "} " + super.toString();
    }
}
