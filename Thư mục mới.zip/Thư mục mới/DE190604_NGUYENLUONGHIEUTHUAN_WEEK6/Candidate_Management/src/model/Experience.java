package model;

import java.util.Date;

public class Experience extends Candidate {
    private  int ExplnYear;
    private  String ProSkill;


    public Experience(String Candidate_Id, String FirstName, String LastName, Date BirthDate, String Address, String Phone, String Email, int Candidate_Type,int ExplnYear, String ProSkill) {
        super(Candidate_Id, FirstName, LastName, BirthDate, Address, Phone, Email, Candidate_Type);
        this.ExplnYear = ExplnYear;
        this.ProSkill = ProSkill;
    }

    public int getExplnYear() {
        return ExplnYear;
    }

    public String getProSkill() {
        return ProSkill;
    }

    public void setExplnYear(int explnYear) {
        ExplnYear = explnYear;
    }

    public void setProSkill(String proSkill) {
        ProSkill = proSkill;
    }

    @Override
    public String toString() {
        return "Experience{" +
                "ExplnYear=" + ExplnYear +
                ", ProSkill='" + ProSkill + '\'' +
                "} " + super.toString();
    }
}
