package model;

import java.util.Date;

public class Intern extends  Candidate {
    private String Major;
    private  String Semester;
    private  String UniversityName;

    public Intern(String Candidate_Id, String FirstName, String LastName, Date BirthDate, String Address, String Phone, String Email, int Candidate_Type, String Major, String Semester, String UniversityName) {
        super(Candidate_Id, FirstName, LastName, BirthDate, Address, Phone, Email, Candidate_Type);
        this.Major = Major;
        this.Semester = Semester;
        this.UniversityName = UniversityName;
    }

    public String getMajor() {
        return Major;
    }

    public void setMajor(String major) {
        Major = major;
    }

    public String getSemester() {
        return Semester;
    }

    public void setSemester(String semester) {
        Semester = semester;
    }

    public String getUniversityName() {
        return UniversityName;
    }

    public void setUniversityName(String universityName) {
        UniversityName = universityName;
    }

    @Override
    public String toString() {
        return "Intern{" +
                "Major='" + Major + '\'' +
                ", Semester='" + Semester + '\'' +
                ", UniversityName='" + UniversityName + '\'' +
                "} " + super.toString();
    }
}
