package controller;

import model.Candidate;
import model.CandidateList;
import view.Candidate_Management;
import view.Menu;

public class Main {
    public  static  void main(String[]args){
        Candidate_Management view = new Candidate_Management();
        CandidateList candidateList = new CandidateList();
        String[] choices = {
                "1.Experience",
                "2.Fresher",
                "3.Intern",
                "4.Search",
                "5.Exiting..."
        };
        Menu menu = new Menu("Candidate Management", choices) {
            @Override
            public void execute(int n) {
                switch (n){
                    case 1:
                        view.createCandidate(candidateList,0);

                        break;
                    case 2:
                        view.createCandidate(candidateList,1);
                        break;
                    case 3:
                        view.createCandidate(candidateList,2);
                        break;
                    case 4:
                        view.searchByName();
                        break;
                    case 5:
                        System.exit(0);
                }
            }
        };
        menu.run();
    }
}
