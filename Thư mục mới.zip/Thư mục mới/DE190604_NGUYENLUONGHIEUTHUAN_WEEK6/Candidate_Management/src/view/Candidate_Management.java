package view;

import model.*;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Candidate_Management {
private CandidateList candidateList;

public Candidate_Management(){
    this.candidateList = new CandidateList();


}
    public Intern createCandidate(CandidateList candidateList , int type) {
        System.out.println(" -------- Add Candidate  -------- ");
        System.out.print("Enter ID: ");
        String Candidate_Id = Validation.inputString();
        System.out.print("Enter First Name: ");
        String firstName = Validation.inputName();
        System.out.print("Enter Last Name: ");
        String lastName = Validation.inputName();
        System.out.println("Enter Birth Date: ");
        Date birthDate = Validation.inputDate();
        System.out.print("Enter Address: ");
        String address = Validation.inputString();
        System.out.print("Enter Phone Number: ");
        String phone = Validation.inputPhoneNumber();
        System.out.println("Enter Email: ");
        String email = Validation.inputEmailFormat();

        switch (type) {
            case 0:
                System.out.println("Enter Experience: ");
                int exp = Validation.inputLimitedPositiveInt( 0, 100);
                System.out.print("Enter Professional Skill: ");
                String proSkill = Validation.inputString();
                candidateList.addCandidate(new Experience(Candidate_Id, firstName, lastName, birthDate, address, phone, email,0 , exp, proSkill));
                break;
            case 1:
                System.out.print("Enter Graduation Date: ");
                LocalDate gradDate = Validation.inputLocalDate();
                System.out.println("Enter Graduation Rank: ");
                String gradRank = Validation.inputString();
                System.out.print("Enter Education: ");
                String education = Validation.inputString();
                candidateList.addCandidate(new Fresher(Candidate_Id, firstName, lastName, birthDate, address, phone, email ,1,gradDate,gradRank,education));
                break;
            case 2:
                System.out.print("Enter Major: ");
                String major = Validation.inputString();
                System.out.println("Enter Semester: ");
                String semester = Validation.inputString();
                System.out.print("Enter University Name: ");
                String university = Validation.inputString();
                candidateList.addCandidate( new Intern(Candidate_Id, firstName, lastName, birthDate, address, phone, email,2, major, semester, university));
                break;
            default:
    }

        return null;
    }
public CandidateList searchByName(){
    System.out.println("nhap ten :");
    String name1 = Validation.inputName();
    System.out.println(" nhap kieu muon tim ( 0 - 2)");
    int type = Validation.inputPositiveInt();
    List<Candidate> results = candidateList.searchCandidate(name1,type);
    results.forEach(System.out::println);


    return (CandidateList) candidateList.getCandidateList();
}
}





