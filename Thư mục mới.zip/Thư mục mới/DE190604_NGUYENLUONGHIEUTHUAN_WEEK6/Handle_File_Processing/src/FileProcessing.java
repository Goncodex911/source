import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class FileProcessing {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n===== File Processing Program =====");
            System.out.println("1. Check if a path exists (File/Directory)");
            System.out.println("2. List all .java files in a directory");
            System.out.println("3. Find files larger than N KB in a directory");
            System.out.println("4. Append content to a file");
            System.out.println("5. Count words in a .txt file");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1 ->
                        checkPath();
                case 2 ->
                        listJavaFiles();
                case 3 ->
                        findLargeFiles();
                case 4 ->
                        appendToFile();
                case 5 ->
                        countWordsInFile();
                case 6 -> {
                    System.out.println("Exiting program...");
                    return;
                }
                default ->
                        System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void checkPath() {
        System.out.print("Enter path: ");
        String pathStr = scanner.nextLine();
        Path path = Paths.get(pathStr);

        if (!Files.exists(path)) {
            System.out.println("Path does not exist.");
            return;
        }
        if (Files.isDirectory(path)) {
            System.out.println("The path is a directory.");
        } else {
            System.out.println("The path is a file.");
        }
    }

    private static void listJavaFiles() {
        System.out.print("Enter directory path: ");
        String dirPath = scanner.nextLine();
        File dir = new File(dirPath);

        if (!dir.exists() || !dir.isDirectory()) {
            System.out.println("Invalid directory path.");
            return;
        }

        File[] files = dir.listFiles();
        if (files == null || files.length <= 0) {
            System.out.println("No .java files found.");
            return;
        }
        System.out.println("Java files in directory:");
        for (File file : files) {
            if (file.getName().endsWith(".java")) {
                System.out.println(file.getName());
            }
        }
    }

    private static void findLargeFiles() {
        System.out.print("Enter directory path: ");
        String dirPath = scanner.nextLine();
        System.out.print("Enter file size limit (in KB): ");
        int sizeLimit = Integer.parseInt(scanner.nextLine()) * 1024;

        File dir = new File(dirPath);
        if (!dir.exists() || !dir.isDirectory()) {
            System.out.println("Invalid directory path.");
            return;
        }

        File[] files = dir.listFiles();
        if (files == null || files.length <= 0) {
            System.out.println("No files found larger than " + (sizeLimit / 1024) + " KB.");
            return;

        }
        System.out.println("Files larger than " + (sizeLimit / 1024) + " KB:");
        for (File file : files) {
            if (file.isFile() && file.length() > sizeLimit) {
                System.out.println(file.getName() + " - " + file.length() / 1024 + " KB");
            }
        }
    }

    private static void appendToFile() {
        System.out.print("Enter file path: ");
        String filePath = scanner.nextLine();
        File file = new File(filePath);

        if (!file.exists() || !file.isFile()) {
            System.out.println("Invalid file path.");
            return;
        }

        System.out.println("Enter content to append (type 'EOF' on a new line to stop):");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            while (true) {
                String line = scanner.nextLine();
                if (line.equalsIgnoreCase("EOF".trim())) {
                    break;
                }
                writer.write(line);
                writer.newLine();
            }
            System.out.println("Content appended successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    private static void countWordsInFile() {
        System.out.print("Enter file path: ");
        String filePath = scanner.nextLine();
        File file = new File(filePath);

        if (!file.exists() || !file.isFile() || !filePath.endsWith(".txt")) {
            System.out.println("Invalid text file path.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            int wordCount = 0;
            String line;
            while ((line = reader.readLine()) != null) {
                wordCount += line.split("\\s+").length;
            }
            System.out.println("Total words in file: " + wordCount);
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}
