package model;

public enum BMI {
    UNDER_STANARD(" Bmi < 19"),
    STANDARD(" Bmi tu 19 den 25"),
    OVERWEIGHT("Bmi tu 25 den 30"),
    FAT("Bmi tu 30 den 40"),
    VERYFAT("Bmi > 40");
    private String bmi;
    BMI(String bmi) {
        this.bmi = bmi;
    }
    public String getBmi() {
        return bmi;
    }
    public  static BMI fromString(String bmi){
        for(BMI b:BMI.values()){
            if(b.getBmi().equals(bmi)){
                return b;
            }
        }
        return null;
    }
}
