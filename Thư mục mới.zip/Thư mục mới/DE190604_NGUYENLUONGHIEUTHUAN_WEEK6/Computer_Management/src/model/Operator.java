package model;

public enum Operator {
    ADD("PHEP CONG '+' "),
    SUBTRACT("pHEP TRU '-'"),
    MULTIPLY("PHEP NHAN '*' "),
    DIVIDE("PHEP CHIA '/' "),
    EXPONENT("PHEP MU '^' "),
    EQUAL("PHAI HAM EQUAL '=' ");
    private String operator;

    Operator(String operator) {
        this.operator = operator;
    }
    public String getOperator() {
        return operator;
    }
    public  static Operator fromString(String operator){
        for(Operator op:Operator.values()){
            if(op.getOperator().equals(operator)){
                return op;
            }
        }
        return null;
    }

}
