package view;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.Scanner;

public class Validation {

    public static String inputStringWithoutNum() {
        Scanner scanner = new Scanner(System.in);
        String input = null;
        String regex = "^[A-Za-zÀ-ÖØ-öø-ÿ\\s]+$";
        do {
            System.out.print("Input a String: ");
            input = scanner.nextLine();
            if (input.trim().isEmpty() || !input.matches(regex)) {
                System.out.println("Wrong input. Please enter a valid string with allowed characters.");
                input = null;
            }
        } while (input == null);

        return input;
    }

    public static String inputString() {
        Scanner scanner = new Scanner(System.in);
        String input = null;
        String regex = "^[A-Za-zÀ-ÖØ-öø-ÿ0-9\\s]+$";
        do {
            System.out.print("Input a String: ");
            input = scanner.nextLine();
            if (input.trim().isEmpty() || !input.matches(regex)) {
                System.out.println("Wrong input. Please enter a valid string with allowed characters.");
                input = null;
            }
        } while (input == null);

        return input;
    }

    public static int inputTrueOrFalse() {
        Scanner scanner = new Scanner(System.in);
        String input;
        int check = -1;
        do {
            System.out.print("True or False: ");
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("true")) {

                check = 1;
            } else if (input.equalsIgnoreCase("false")) {
                check = 0;
            } else {
                check = -1;
            }
        } while (check == -1);

        return check;
    }

    public static String inputString(boolean nullable) {
        Scanner scanner = new Scanner(System.in);
        String input = null;
        do {
            System.out.print("Input a String: ");
            input = scanner.nextLine();
            if (nullable && input.isBlank()) {
                return null;
            }
        } while (input == null);

        return input;
    }

    public static String inputName() {
        Scanner scanner = new Scanner(System.in);
        String input = null;
        boolean cont = true;
        do {
            System.out.print("Input a String: ");
            input = scanner.nextLine();

        } while (input == null || input.trim().isEmpty());
        return input;
    }

    public static String inputPhoneNumber() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            String phone = scanner.nextLine();
            if (phone.matches("^\\d{10,}$")) {
                return phone;
            } else {
                System.out.println("Phone number must be at least 10 characters long. Please enter again!");
            }
        }
    }

    public static String inputEmailFormat() {
        Scanner scanner = new Scanner(System.in);
        String regex = "^[\\w.%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$";
        while (true) {
            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            if (!email.matches(regex)) {
                System.out.println("Email must follow the format <account name>@<domain>!");
            } else {
                return email;
            }
        }
    }

    public static String inputY_N() {
        String input = null;
        boolean cont = true;
        do {
            input = inputString().trim();
            if (input.equalsIgnoreCase("y") || input.equalsIgnoreCase("n")) {
                cont = false;
            } else {
                System.out.println("Please type" + " Y " + "or" + " N :");
            }
        } while (cont);
        return input;
    }

    public static int inputPositiveInt() {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        int inputInt = -1;
        do {
            try {
                System.out.println("(Input a positive integer)");
                inputInt = Integer.parseInt(scanner.nextLine());
                cont = false;
                if (inputInt <= 0) {
                    System.out.println("(Input a positive integer!)");
                    System.out.println("-----------------------");
                    cont = true;
                }
            } catch (Exception e) {
                System.out.println("(Input a positive integer!)");
                System.out.println("-----------------------");
            }

        } while (cont);
        return inputInt;
    }

    public static LocalDate inputLocalDate() {
        Scanner scanner = new Scanner(System.in);
        LocalDate date = null;
        boolean cont = true;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        do {
            try {
                System.out.println("Input date (dd-MM-yyy):");
                String inputDate = scanner.nextLine();
                date = LocalDate.parse(inputDate, formatter);

                YearMonth yearMonth = YearMonth.of(date.getYear(), date.getMonth());

                if (!inputDate.equals(date.format(formatter))) {
                    System.out.println("The entered date is not valid.");
                    System.out.println("-----------------------");
                    continue;
                }
                if (Period.between(date, LocalDate.now()).getYears() < 18) {
                    System.out.println("Employee must be above 18 years old!.");
                    System.out.println("-----------------------");
                    continue;
                }

                cont = false;
            } catch (Exception e) {
                System.out.println("Invalid date");
                System.out.println("-----------------------");
            }
        } while (cont);

        return date;
    }

    public static Date inputDate() {
        Scanner scanner = new Scanner(System.in);
        Date date = null;
        boolean cont = true;
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        sdf.setLenient(false);
        do {
            try {
                System.out.println("Input date (dd-MM-yyy):");
                String inputDate = scanner.nextLine();
                date = sdf.parse(inputDate);
                cont = false;
            } catch (Exception e) {
                System.out.println("Invalid date");
                System.out.println("-----------------------");
            }
        } while (cont);

        return date;
    }

    public static Date inputDate(boolean nullable) {
        Scanner scanner = new Scanner(System.in);
        Date date = null;
        boolean cont = true;
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        sdf.setLenient(false);
        do {
            try {
                System.out.println("Input date (dd-MM-yyy):");
                String inputDate = scanner.nextLine();
                if (nullable && inputDate.isBlank()) {
                    return null;
                }
                date = sdf.parse(inputDate);
                cont = false;
            } catch (Exception e) {
                System.out.println("Invalid date");
                System.out.println("-----------------------");
            }
        } while (cont);

        return date;
    }

    public static double inputPositiveDouble() {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        double inputInt = -1;
        do {
            try {
                System.out.println("Input a positive double");
                inputInt = Double.parseDouble(scanner.nextLine());
                cont = false;
                if (inputInt <= 0) {
                    System.out.println("Wrong number,input a positive double:");
                    System.out.println("-----------------------");
                    cont = true;
                }
            } catch (Exception e) {
                System.out.println("Wrong input,Input a positive double:");
                System.out.println("-----------------------");
            }

        } while (cont);

        return inputInt;
    }

    public static double inputPositiveDoubleZeroAble() {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        double inputInt = -1;
        do {
            try {
                System.out.println("Input a positive double");
                inputInt = Double.parseDouble(scanner.nextLine());
                cont = false;
                if (inputInt < 0) {
                    System.out.println("Wrong number,input a positive double:");
                    System.out.println("-----------------------");
                    cont = true;
                }
            } catch (Exception e) {
                System.out.println("Wrong input,Input a positive double:");
                System.out.println("-----------------------");
            }

        } while (cont);

        return inputInt;
    }

    public static double inputPositiveDouble(boolean nullable) {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        double inputInt = -1;
        do {
            try {
                System.out.println("Input a positive double");
                String inputString = scanner.nextLine();
                if (inputString.isBlank() && nullable) {
                    return 0;
                }
                inputInt = Double.parseDouble(inputString);
                cont = false;
                if (inputInt <= 0) {
                    System.out.println("Wrong number,input a positive double:");
                    System.out.println("-----------------------");
                    cont = true;
                }
            } catch (Exception e) {
                System.out.println("Wrong input,Input a positive double:");
                System.out.println("-----------------------");
            }

        } while (cont);

        return inputInt;
    }

    public static int inputLimitedPositiveInt(int min, int max) {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        int inputInt = -1;
        do {
            try {
                System.out.println("Input a positive integer between " + min + " and " + max + " :");
                inputInt = Integer.parseInt(scanner.nextLine());
                cont = false;
                if (inputInt <= 0 || inputInt < min || inputInt > max) {
                    System.out.println("Wrong number,input a positive integer between " + min + " and " + max + " :");
                    System.out.println("-----------------------");
                    cont = true;
                }
            } catch (Exception e) {
                System.out.println("Wrong input,Input a positive integer between " + min + " and " + max + " :");
                System.out.println("-----------------------");
            }

        } while (cont);

        return inputInt;
    }

    public static double inputLimitedPositiveDouble(double min, double max) {
        Scanner scanner = new Scanner(System.in);
        boolean cont = true;
        double inputInt = -1.0;
        do {
            try {
                System.out.println("Input a positive double between " + min + " and " + max + " :");
                inputInt = Double.parseDouble(scanner.nextLine());
                cont = false;
                if (inputInt <= 0 || inputInt < min || inputInt > max) {
                    System.out.println("Wrong number,input a positive double between " + min + " and " + max + " :");
                    System.out.println("-----------------------");
                    cont = true;
                }
            } catch (Exception e) {
                System.out.println("Wrong input,Input a positive double between " + min + " and " + max + " :");
                System.out.println("-----------------------");
            }

        } while (cont);

        return inputInt;
    }

    public static String inputLimitString(HashSet<String> limitString) {
        Scanner scanner = new Scanner(System.in);
        String input = null;
        do {
            System.out.print("Input a String in: " + limitString.toString());
            input = scanner.nextLine();
            if (input.trim().isEmpty()) {
                System.out.println("Wrong input. Please enter a valid string with allowed characters.");
                input = null;
                continue;
            }

            if (!limitString.contains(input)) {
                System.out.println("Wrong input. Please enter a valid string with allowed characters.");
                input = null;
            }
        } while (input == null);

        return input;
    }


    public static String inputLimitString(HashSet<String> limitString, boolean nullable) {
        Scanner scanner = new Scanner(System.in);
        String input = null;
        String regex = "^[A-Za-zÀ-ÖØ-öø-ÿ0-9\\s]+$";
        do {
            System.out.print("Input a String in: " + limitString.toString());
            input = scanner.nextLine();
            if (input.trim().isEmpty() && nullable) {
                return null;
            }
            if (!input.matches(regex)) {
                System.out.println("Wrong input. Please enter a valid string with allowed characters.");
                input = null;
            }

            if (!limitString.contains(input)) {
                System.out.println("Wrong input. Please enter a valid string with allowed characters.");
                input = null;
            }
        } while (input == null);

        return input;
    }

    public static String inputU_D() {
        String input = null;
        boolean cont = true;
        do {
            input = inputString().trim();
            if (input.equalsIgnoreCase("U") || input.equalsIgnoreCase("D")) {
                cont = false;
            } else {
                System.out.println("Please type" + " U " + "or" + " D :");
            }
        } while (cont);
        return input;
    }

}
