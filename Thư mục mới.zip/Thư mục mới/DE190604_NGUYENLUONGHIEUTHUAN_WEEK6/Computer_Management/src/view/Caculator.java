package view;

import model.BMI;
import model.Operator;

import java.util.Scanner;
public class Caculator {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("========= Calculator Program =========");
            System.out.println("1. Normal Calculator");
            System.out.println("2. BMI Calculator");
            System.out.println("3. Exit");
            System.out.print("Please choose one option: ");

            String choice = scanner.nextLine();
            switch (choice) {
                case "1": normalCalculator(); break;
                case "2": bmiCalculator(); break;
                case "3": System.out.println("Exiting program..."); return;
                default: System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void normalCalculator() {
        System.out.println("----- Normal Calculator -----");
        double memory = getValidDouble("Enter number: ");
        while (true) {
            System.out.print("Enter Operator: ");
            String opInput = scanner.nextLine();
            Operator operator = Operator.fromString(opInput);

            if (operator == null) {
                System.out.println("Please input (+, -, *, /, ^, =)");
                continue;
            }
            if (operator == Operator.EQUAL) {
                System.out.println("Result: " + memory);
                break;
            }
            double num = getValidDouble("Enter number: ");
            memory = calculate(memory, operator, num);
            System.out.println("Memory: " + memory);
        }
    }

    private static void bmiCalculator() {
        System.out.println("----- BMI Calculator -----");
        double weight = getValidDouble("Enter Weight(kg): ");
        double height = getValidDouble("Enter Height(cm): ") / 100; // Convert cm to m

        double bmi = calculateBMI(weight, height);
        System.out.println("BMI Number: " + String.format("%.2f", bmi));
        System.out.println("BMI Status: " + BMI.fromString(String.format("%.2f", bmi)).getBmi());
    }

    private static double calculate(double a, Operator operator, double b) {
        switch (operator) {
            case ADD: return a + b;
            case SUBTRACT: return a - b;
            case MULTIPLY: return a * b;
            case DIVIDE:
                if (b == 0) {
                    System.out.println("Error: Division by zero.");
                    return a;
                }
                return a / b;
            case EXPONENT: return Math.pow(a, b);
            default: return a;
        }
    }

    private static double calculateBMI(double weight, double height) {
        return weight / (height * height);
    }

    private static double getValidDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a numeric value.");
            }
        }
    }
}


